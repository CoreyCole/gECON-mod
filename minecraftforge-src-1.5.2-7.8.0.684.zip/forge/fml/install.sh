#!/bin/bash
python install.py
